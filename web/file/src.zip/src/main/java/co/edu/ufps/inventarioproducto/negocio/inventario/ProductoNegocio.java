/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.ufps.inventarioproducto.negocio.inventario;

import co.edu.ufps.inventarioproducto.capadatos.dao.ProductoDao;
import co.edu.ufps.inventarioproducto.capadatos.entidades.Producto;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class ProductoNegocio {
    
    private ProductoDao productoDao;

    public ProductoNegocio() {
        productoDao = new ProductoDao();
    }
            
    public String insertarProducto(Producto p){
        String rta="";
        try {
            Producto pe = productoDao.buscarProducto(p.getId());
            if (pe==null){
                int saldo = p.getExistencias() * p.getCostoUnitario();
                p.setSaldoInventario(saldo);
                boolean res = productoDao.insertarProducto(p);
                if (res) rta = "Producto guardado con éxito." ;
                else rta = "Error al guardar el producto";
            } else rta = "El producto ya fue creado";                       
        } catch (Exception e) {
            rta="Error al guardar el producto";
            e.printStackTrace();
        }
        return rta;
    }
    
    public Producto buscarProducto(String id){
        Producto p = new Producto();
        try {
            p = productoDao.buscarProducto(id);
        } catch (Exception e) {
            e.printStackTrace();
            p= null;
        }
        return p;
    }
    
    public List<Producto> buscarProductos(){
        List<Producto> productos;
        try {
            productos = productoDao.buscarProductos();
        } catch (Exception e) {
            e.printStackTrace();
            productos= null;
        }
        return productos;
    }
    
}
