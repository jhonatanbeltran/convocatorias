/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.ufps.inventarioproducto.capadatos.entidades;

import java.util.Objects;

/**
 *
 * @author Usuario
 */
public class Producto {
    private String id;
    private String nombre;
    private String tipo;
    private int precioVenta;
    private int existencias;
    private int costoUnitario;
    private int saldoInventario;
    
    public Producto(){
        super();
    }
    
    public Producto(String id, String nombre, String tipo, int precioVenta, int existencias, int costoUnitario, int saldoInventario) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.precioVenta = precioVenta;
        this.existencias = existencias;
        this.costoUnitario = costoUnitario;
        this.saldoInventario = saldoInventario;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    } 

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(int precioVenta) {
        this.precioVenta = precioVenta;
    }

    public int getExistencias() {
        return existencias;
    }

    public void setExistencias(int existencias) {
        this.existencias = existencias;
    }

    public int getCostoUnitario() {
        return costoUnitario;
    }

    public void setCostoUnitario(int costoUnitario) {
        this.costoUnitario = costoUnitario;
    }

    public int getSaldoInventario() {
        return saldoInventario;
    }

    public void setSaldoInventario(int saldoInventario) {
        this.saldoInventario = saldoInventario;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 73 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }        
}
