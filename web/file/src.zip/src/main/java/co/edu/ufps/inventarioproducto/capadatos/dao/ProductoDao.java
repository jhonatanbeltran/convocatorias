/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.ufps.inventarioproducto.capadatos.dao;

import co.edu.ufps.inventarioproducto.capadatos.Conexion;
import co.edu.ufps.inventarioproducto.capadatos.entidades.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class ProductoDao {
    
    public boolean insertarProducto(Producto producto)throws Exception{
        boolean rta=false;
        
        Conexion con= new Conexion();
        Connection conexion = con.conectar("ProductoDao.insertarProducto()");
        String sql = "INSERT INTO producto VALUES (?,?,?,?,?,?,?)";
        PreparedStatement ps = conexion.prepareStatement(sql);
        
        ps.setString(1, producto.getId());
        ps.setString(2, producto.getNombre());
        ps.setString(3, producto.getTipo());
        ps.setInt(4, producto.getPrecioVenta());
        ps.setInt(5, producto.getExistencias());
        ps.setInt(6, producto.getCostoUnitario());
        ps.setInt(7, producto.getSaldoInventario());
        
        ps.execute();
        rta=true;
        
        ps.close();
        conexion.close();
        
        ps=null;
        conexion=null;
        return rta;
    }
    
    public Producto buscarProducto(String codigo)throws Exception{
        Producto p = new Producto();
        
        Conexion con= new Conexion();
        Connection conexion = con.conectar("ProductoDao.buscarProducto()");
        String sql = "SELECT * FROM producto WHERE id = ?";
        PreparedStatement ps = conexion.prepareStatement(sql);
        
        ps.setString(1, codigo);                
        ResultSet rst = ps.executeQuery();
        if (rst.next()){
            p.setId(rst.getString(1));
            p.setNombre(rst.getString(2));
            p.setTipo(rst.getString(3));
            p.setPrecioVenta(rst.getInt(4));
            p.setExistencias(rst.getInt(5));
            p.setCostoUnitario(rst.getInt(6));
            p.setSaldoInventario(rst.getInt(7));
        } else p=null;
        
        rst.close();        
        ps.close();
        conexion.close();
        
        rst=null;
        ps=null;
        conexion=null;
        return p;
    }
    
    public List<Producto> buscarProductos()throws Exception{
        List<Producto> productos = new ArrayList<>();
                
        Conexion con= new Conexion();
        Connection conexion = con.conectar("ProductoDao.buscarProductos()");
        String sql = "SELECT * FROM producto ";
        PreparedStatement ps = conexion.prepareStatement(sql);
                
        ResultSet rst = ps.executeQuery();
        while (rst.next()){
            Producto p = new Producto();
            p.setId(rst.getString(1));
            p.setNombre(rst.getString(2));
            p.setTipo(rst.getString(3));
            p.setPrecioVenta(rst.getInt(4));
            p.setExistencias(rst.getInt(5));
            p.setCostoUnitario(rst.getInt(6));
            p.setSaldoInventario(rst.getInt(7));
            
            productos.add(p);
        }
        
        rst.close();        
        ps.close();
        conexion.close();
        
        rst=null;
        ps=null;
        conexion=null;
        return productos;
    }
}
