/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.ufps.inventarioproducto.negocio.facade;

import co.edu.ufps.inventarioproducto.capadatos.entidades.Producto;
import co.edu.ufps.inventarioproducto.negocio.inventario.ProductoNegocio;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class InventarioFacade {
    private ProductoNegocio productoNegocio;

    public InventarioFacade() {
        productoNegocio = new ProductoNegocio();
    }
    
    public String insertarProducto(Producto p){
        return productoNegocio.insertarProducto(p);
    }  
    
    public Producto buscarProducto(String id){
        return productoNegocio.buscarProducto(id);
    }
    
    public List<Producto> buscarProductos(){
        return productoNegocio.buscarProductos();
    }
}
